# LAN Hub Manager

Una aplicación para Linux que convierte tu PC en un hub LAN, usando una tarjeta de red para entrada y hasta cuatro para salida, mientras mantienes la conectividad a internet.

## Características

- Interfaz web fácil de usar para gestionar todas las configuraciones
- Soporte para convertir tu PC en un hub de red
- Asigna automáticamente diferentes subredes a cada puerto LAN
- Servidor DHCP integrado para asignar direcciones IP automáticamente
- Monitoreo de tráfico y clientes conectados en tiempo real
- Fácil configuración y gestión de reglas de firewall

## Requisitos

Para usar esta aplicación, necesitas:

- Un sistema Linux (Ubuntu, Debian, CentOS, etc.)
- Python 3.6 o superior
- Los siguientes paquetes del sistema:
  - `iproute2` (para comandos `ip`)
  - `iptables` (para reglas de firewall)
  - `dnsmasq` (para servidor DHCP)
  - `sysctl` (para configurar el reenvío de paquetes)
- Al menos dos interfaces de red (una para WAN/Internet y al menos una para LAN)
- Permisos de superusuario (root) para configurar las interfaces de red

## Instalación

1. Clona este repositorio:
```bash
git clone https://github.com/tu-usuario/lanhub-manager.git
cd lanhub-manager
```

2. Instala las dependencias de Python:
```bash
pip install -r requirements.txt
```

3. Instala los paquetes del sistema necesarios:
```bash
# En sistemas basados en Debian/Ubuntu
sudo apt update
sudo apt install iproute2 iptables dnsmasq

# En sistemas basados en CentOS/RHEL
sudo yum install iproute iptables dnsmasq
```

## Uso

1. Inicia la aplicación con permisos de superusuario (necesario para configurar interfaces):
```bash
sudo python main.py
```

2. Abre un navegador web y ve a: `http://localhost:5050`

3. En la interfaz web:
   - Configura qué interfaz de red usar para WAN (conexión a internet)
   - Selecciona hasta 4 interfaces para usar como puertos LAN
   - Configura las opciones de DHCP según sea necesario
   - Haz clic en "Start Hub" para activar la funcionalidad de hub

## Diagrama de Funcionamiento

```
                        +---------------+
                        |               |
INTERNET <--------> WAN |   TU PC CON   | LAN1 <------> Dispositivo 1 (192.168.1.x)
                        | LAN HUB MANAGER | LAN2 <------> Dispositivo 2 (192.168.2.x)
                        |               | LAN3 <------> Dispositivo 3 (192.168.3.x)
                        +---------------+ LAN4 <------> Dispositivo 4 (192.168.4.x)
                          ^
                          |
                        GESTIÓN WEB
                      (localhost:5050)
```

## Solución de Problemas

Si encuentras problemas al usar la aplicación:

1. Asegúrate de que todas las dependencias están instaladas correctamente
2. Verifica que tienes permisos de superusuario al ejecutar la aplicación
3. Comprueba que las interfaces de red están correctamente conectadas y reconocidas por el sistema
4. Revisa los registros de la aplicación para ver mensajes de error detallados

## Seguridad

Esta aplicación realiza cambios en la configuración de red de tu sistema. Se recomienda:

- Usar en entornos controlados y seguros
- No exponer la interfaz web a internet
- Revisar periódicamente los registros del sistema
- Asegurarse de que los firewalls están configurados correctamente

## Licencia

Este proyecto está licenciado bajo la Licencia MIT.