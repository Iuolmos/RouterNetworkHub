import os
import json
import logging
import tempfile

logger = logging.getLogger(__name__)

class ConfigManager:
    """Manages configuration for the LAN hub application"""
    
    def __init__(self, config_file=None):
        """Initialize config manager with optional config file path"""
        # Default config file location in user's home directory
        self.config_file = config_file or os.path.expanduser("~/.lanhub_config.json")
        self.config = self._load_config()
    
    def get_config(self):
        """Get current configuration"""
        return self.config
    
    def save_config(self, config):
        """Save configuration to file"""
        self.config = config
        self._save_config()
    
    def _load_config(self):
        """Load configuration from file"""
        default_config = {
            'wan_interface': None,
            'lan_interfaces': [],
            'dhcp_enabled': True,
            'dhcp_start': '100',
            'dhcp_end': '200',
            'subnet_mask': '255.255.255.0'
        }
        
        # Create config file with default values if it doesn't exist
        if not os.path.exists(self.config_file):
            logger.info(f"Config file not found, creating default at {self.config_file}")
            self._save_config(default_config)
            return default_config
        
        # Load existing config
        try:
            with open(self.config_file, 'r') as f:
                config = json.load(f)
                logger.info(f"Configuration loaded from {self.config_file}")
                
                # Ensure all required fields are present
                for key, value in default_config.items():
                    if key not in config:
                        config[key] = value
                
                return config
        
        except Exception as e:
            logger.error(f"Error loading configuration: {str(e)}")
            return default_config
    
    def _save_config(self, config=None):
        """Save configuration to file"""
        if config is None:
            config = self.config
        
        try:
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(os.path.abspath(self.config_file)), exist_ok=True)
            
            # Write config directly to the file
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=4)
            
            logger.info(f"Configuration saved to {self.config_file}")
        
        except Exception as e:
            logger.error(f"Error saving configuration: {str(e)}")
            # Use a more reliable fallback location if the original location fails
            try:
                fallback_path = os.path.join(os.getcwd(), 'lanhub_config.json')
                with open(fallback_path, 'w') as f:
                    json.dump(config, f, indent=4)
                self.config_file = fallback_path
                logger.info(f"Configuration saved to fallback location: {fallback_path}")
            except Exception as e2:
                logger.error(f"Failed to save config to fallback location: {str(e2)}")
