/**
 * LAN Hub Manager Dashboard JavaScript
 * Handles dynamic UI updates and API interactions
 */

document.addEventListener('DOMContentLoaded', function() {
    // Elements
    const toggleHubBtn = document.getElementById('toggle-hub-btn');
    const hubStatusText = document.getElementById('hub-status-text');
    const hubStatusIndicator = document.getElementById('hub-status-indicator');
    
    /**
     * Toggle the LAN hub status (on/off)
     * @param {boolean} enabled - Whether to enable the hub
     */
    window.toggleHub = function(enabled) {
        // Show loading state
        const originalBtnText = toggleHubBtn.innerHTML;
        toggleHubBtn.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...';
        toggleHubBtn.disabled = true;
        
        // Call API
        fetch('/api/toggle_hub', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ enabled: enabled })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update UI
                if (data.enabled) {
                    toggleHubBtn.innerHTML = 'Stop Hub';
                    toggleHubBtn.classList.remove('btn-success');
                    toggleHubBtn.classList.add('btn-danger');
                    hubStatusText.textContent = 'Active';
                    hubStatusIndicator.querySelector('.status-dot').classList.remove('status-inactive');
                    hubStatusIndicator.querySelector('.status-dot').classList.add('status-active');
                } else {
                    toggleHubBtn.innerHTML = 'Start Hub';
                    toggleHubBtn.classList.remove('btn-danger');
                    toggleHubBtn.classList.add('btn-success');
                    hubStatusText.textContent = 'Inactive';
                    hubStatusIndicator.querySelector('.status-dot').classList.remove('status-active');
                    hubStatusIndicator.querySelector('.status-dot').classList.add('status-inactive');
                }
                
                // Reload page after 2 seconds to refresh interface data
                setTimeout(() => {
                    window.location.reload();
                }, 2000);
            } else {
                // Show error
                toggleHubBtn.innerHTML = originalBtnText;
                alert('Error: ' + (data.error || 'An unknown error occurred'));
            }
        })
        .catch(error => {
            console.error('Error:', error);
            toggleHubBtn.innerHTML = originalBtnText;
            alert('Error: ' + error.message);
        })
        .finally(() => {
            toggleHubBtn.disabled = false;
        });
    };
    
    // Event listeners
    if (toggleHubBtn) {
        toggleHubBtn.addEventListener('click', function() {
            const currentlyActive = hubStatusText.textContent === 'Active';
            toggleHub(!currentlyActive);
        });
    }
    
    /**
     * Format bytes to human-readable format
     * @param {number} bytes - Number of bytes
     * @param {number} decimals - Number of decimal places
     * @returns {string} Formatted string
     */
    window.formatBytes = function(bytes, decimals = 2) {
        if (bytes === 0) return '0 Bytes';
        
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
        
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    };
    
    /**
     * Format a timestamp for display
     * @param {Date} date - Date object
     * @returns {string} Formatted timestamp
     */
    window.formatTimestamp = function(date) {
        if (!(date instanceof Date)) {
            date = new Date(date);
        }
        
        return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    };
});
