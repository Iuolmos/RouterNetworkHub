# Guía de Instalación de LAN Hub Manager

Esta guía te ayudará a instalar y configurar LAN Hub Manager en tu sistema Linux para convertir tu PC en un hub LAN.

## Requisitos del Sistema

### Hardware
- Una computadora con Linux instalado
- Mínimo dos tarjetas de red (una para WAN/internet y al menos una para LAN)
- Hasta cinco tarjetas de red en total (1 WAN + 4 LAN)

### Software
- Sistema operativo Linux (Ubuntu, Debian, CentOS, etc.)
- Python 3.6 o superior
- Paquetes del sistema necesarios:
  * iproute2
  * iptables
  * dnsmasq
  * sysctl

## Pasos de Instalación

### 1. Instalar dependencias del sistema

**Para Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install -y python3 python3-pip iproute2 iptables dnsmasq
```

**Para CentOS/RHEL:**
```bash
sudo yum install -y python3 python3-pip iproute iptables dnsmasq
```

### 2. Descargar LAN Hub Manager

```bash
git clone https://github.com/tu-usuario/lanhub-manager.git
cd lanhub-manager
```

### 3. Crear entorno virtual e instalar dependencias (opcional pero recomendado)

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

### 4. Ejecutar la aplicación

La aplicación debe ejecutarse con permisos de superusuario para poder configurar las interfaces de red:

```bash
sudo python3 main.py
```

Ahora puedes abrir un navegador y acceder a la aplicación en: `http://localhost:5050`

## Configuración

1. En la página de Configuración (Settings), selecciona:
   - Interfaz WAN: La tarjeta de red conectada a internet
   - Interfaces LAN: Hasta 4 tarjetas de red para conectar dispositivos

2. Configura las opciones de DHCP:
   - Rango de direcciones IP
   - Máscara de subred

3. Guarda la configuración y regresa al Dashboard

4. Haz clic en "Start Hub" para activar la funcionalidad del hub

## Verificación

Para verificar que todo funciona correctamente:

1. Conecta un dispositivo (como una computadora o smartphone) a una de las interfaces LAN
2. El dispositivo debería recibir automáticamente una dirección IP (si DHCP está habilitado)
3. Deberías poder navegar por internet desde el dispositivo conectado
4. En la página de Estado (Status) de LAN Hub Manager, podrás ver el tráfico y los clientes conectados

## Solución de Problemas

Si encuentras problemas, verifica:

1. Que todas las interfaces de red estén correctamente conectadas y reconocidas
2. Que estés ejecutando la aplicación con permisos de superusuario
3. Que los paquetes necesarios estén instalados correctamente
4. Los registros de la aplicación para ver mensajes de error detallados

## Uso como Servicio del Sistema

Para configurar LAN Hub Manager como un servicio que se inicie automáticamente:

### Para systemd (Ubuntu, Debian moderno, CentOS 7+):

1. Crea un archivo de servicio:

```bash
sudo nano /etc/systemd/system/lanhub.service
```

2. Añade el siguiente contenido:

```
[Unit]
Description=LAN Hub Manager
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/ruta/completa/a/lanhub-manager
ExecStart=/usr/bin/python3 /ruta/completa/a/lanhub-manager/main.py
Restart=on-failure

[Install]
WantedBy=multi-user.target
```

3. Habilita e inicia el servicio:

```bash
sudo systemctl enable lanhub.service
sudo systemctl start lanhub.service
```

## Desinstalación

Si necesitas desinstalar LAN Hub Manager:

1. Detén el servicio si está configurado:
```bash
sudo systemctl stop lanhub.service
sudo systemctl disable lanhub.service
```

2. Elimina los archivos:
```bash
sudo rm -rf /ruta/a/lanhub-manager
sudo rm /etc/systemd/system/lanhub.service
```

3. Los paquetes instalados (iproute2, iptables, dnsmasq) son útiles para otras aplicaciones, así que considera si quieres mantenerlos.