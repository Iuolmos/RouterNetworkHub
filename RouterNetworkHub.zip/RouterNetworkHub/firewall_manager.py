import os
import subprocess
import logging
from config import ConfigManager

logger = logging.getLogger(__name__)

class FirewallManager:
    """Manages firewall rules for LAN hub functionality"""
    
    def __init__(self, config_manager):
        self.config_manager = config_manager
    
    def setup_firewall(self):
        """Set up firewall rules for NAT and forwarding"""
        config = self.config_manager.get_config()
        wan_interface = config.get('wan_interface')
        lan_interfaces = config.get('lan_interfaces', [])
        
        if not wan_interface or not lan_interfaces:
            logger.warning("Cannot setup firewall: missing WAN or LAN interfaces")
            return
        
        logger.info(f"Setting up firewall with WAN interface {wan_interface} and LAN interfaces {lan_interfaces}")
        
        try:
            # Clear existing rules
            self.reset_firewall()
            
            # Set default policies
            subprocess.run(["iptables", "-P", "INPUT", "ACCEPT"], check=True)
            subprocess.run(["iptables", "-P", "FORWARD", "ACCEPT"], check=True)
            subprocess.run(["iptables", "-P", "OUTPUT", "ACCEPT"], check=True)
            
            # Enable NAT for WAN
            subprocess.run(["iptables", "-t", "nat", "-A", "POSTROUTING", "-o", wan_interface, "-j", "MASQUERADE"], check=True)
            
            # Allow forwarding between interfaces
            for lan_interface in lan_interfaces:
                # Allow established connections
                subprocess.run([
                    "iptables", "-A", "FORWARD", 
                    "-i", lan_interface, "-o", wan_interface, 
                    "-m", "state", "--state", "RELATED,ESTABLISHED", 
                    "-j", "ACCEPT"
                ], check=True)
                
                # Allow new outgoing connections
                subprocess.run([
                    "iptables", "-A", "FORWARD", 
                    "-i", lan_interface, "-o", wan_interface, 
                    "-j", "ACCEPT"
                ], check=True)
                
                # Allow traffic between LAN interfaces
                for other_lan in lan_interfaces:
                    if lan_interface != other_lan:
                        subprocess.run([
                            "iptables", "-A", "FORWARD", 
                            "-i", lan_interface, "-o", other_lan, 
                            "-j", "ACCEPT"
                        ], check=True)
            
            logger.info("Firewall rules set up successfully")
        
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to set up firewall: {str(e)}")
            raise RuntimeError("Failed to set up firewall rules. Check if you have sufficient permissions.")
    
    def reset_firewall(self):
        """Reset firewall to default state"""
        try:
            # Flush all chains
            subprocess.run(["iptables", "-F"], check=True)
            subprocess.run(["iptables", "-t", "nat", "-F"], check=True)
            subprocess.run(["iptables", "-t", "mangle", "-F"], check=True)
            
            # Delete all chains
            subprocess.run(["iptables", "-X"], check=True)
            subprocess.run(["iptables", "-t", "nat", "-X"], check=True)
            subprocess.run(["iptables", "-t", "mangle", "-X"], check=True)
            
            # Set default policies
            subprocess.run(["iptables", "-P", "INPUT", "ACCEPT"], check=True)
            subprocess.run(["iptables", "-P", "FORWARD", "ACCEPT"], check=True)
            subprocess.run(["iptables", "-P", "OUTPUT", "ACCEPT"], check=True)
            
            logger.info("Firewall reset to default state")
        
        except subprocess.CalledProcessError as e:
            logger.error(f"Failed to reset firewall: {str(e)}")
