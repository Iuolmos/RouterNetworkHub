import os
import logging
import subprocess
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash
from network_manager import NetworkManager
from dhcp_manager import DHCPManager
from firewall_manager import FirewallManager
from monitor import NetworkMonitor
from config import ConfigManager
import utils

# Verificar si los comandos necesarios están disponibles
def check_system_commands():
    required_commands = ["ip", "iptables", "dnsmasq", "sysctl"]
    missing = []
    
    for cmd in required_commands:
        try:
            subprocess.check_output(["which", cmd], stderr=subprocess.STDOUT)
        except subprocess.CalledProcessError:
            missing.append(cmd)
    
    return missing

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "lanhubtempkey")

# Verificar comandos del sistema
missing_commands = check_system_commands()
if missing_commands:
    logger.warning(f"Faltan los siguientes comandos necesarios: {', '.join(missing_commands)}")
    # Sólo mostraremos una advertencia, no detendremos la app

# Initialize managers
config_manager = ConfigManager()
network_manager = NetworkManager(config_manager)
dhcp_manager = DHCPManager(config_manager)
firewall_manager = FirewallManager(config_manager)
network_monitor = NetworkMonitor(config_manager)

@app.route('/')
def index():
    """Main dashboard page"""
    network_interfaces = network_manager.get_interfaces()
    hub_status = network_manager.get_hub_status()
    return render_template('index.html', 
                          interfaces=network_interfaces, 
                          hub_status=hub_status)

@app.route('/status')
def status():
    """Network status and monitoring page"""
    interfaces = network_manager.get_interfaces()
    metrics = network_monitor.get_network_metrics()
    clients = network_monitor.get_connected_clients()
    return render_template('status.html', 
                          interfaces=interfaces, 
                          metrics=metrics,
                          clients=clients)

@app.route('/settings')
def settings():
    """Hub configuration settings page"""
    interfaces = network_manager.get_interfaces()
    config = config_manager.get_config()
    return render_template('settings.html', 
                          interfaces=interfaces, 
                          config=config)

@app.route('/api/toggle_hub', methods=['POST'])
def toggle_hub():
    """API endpoint to enable/disable the hub"""
    try:
        request_data = request.get_json()
        if request_data is None:
            return jsonify({"success": False, "error": "Invalid request format"}), 400
            
        enabled = request_data.get('enabled', False)
        if enabled:
            network_manager.enable_hub()
            firewall_manager.setup_firewall()
            dhcp_manager.start_dhcp_server()
            network_monitor.start_monitoring()
            flash("LAN Hub has been enabled successfully.", "success")
        else:
            network_manager.disable_hub()
            firewall_manager.reset_firewall()
            dhcp_manager.stop_dhcp_server()
            network_monitor.stop_monitoring()
            flash("LAN Hub has been disabled.", "info")
        return jsonify({"success": True, "enabled": enabled})
    except Exception as e:
        logger.exception("Error toggling hub")
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/save_config', methods=['POST'])
def save_config():
    """API endpoint to save hub configuration"""
    try:
        # Get form data
        wan_interface = request.form.get('wan_interface')
        lan_interfaces = request.form.getlist('lan_interfaces')
        dhcp_enabled = request.form.get('dhcp_enabled') == 'on'
        dhcp_start = request.form.get('dhcp_start')
        dhcp_end = request.form.get('dhcp_end')
        subnet_mask = request.form.get('subnet_mask')
        
        # Validate inputs
        if not wan_interface:
            flash("WAN interface must be selected", "danger")
            return redirect(url_for('settings'))
            
        if not lan_interfaces:
            flash("At least one LAN interface must be selected", "danger")
            return redirect(url_for('settings'))
            
        # Save configuration
        config = {
            'wan_interface': wan_interface,
            'lan_interfaces': lan_interfaces,
            'dhcp_enabled': dhcp_enabled,
            'dhcp_start': dhcp_start,
            'dhcp_end': dhcp_end,
            'subnet_mask': subnet_mask
        }
        
        config_manager.save_config(config)
        
        # If hub is running, apply changes
        if network_manager.get_hub_status():
            network_manager.disable_hub()
            firewall_manager.reset_firewall()
            dhcp_manager.stop_dhcp_server()
            
            network_manager.enable_hub()
            firewall_manager.setup_firewall()
            if dhcp_enabled:
                dhcp_manager.start_dhcp_server()
        
        flash("Configuration saved successfully", "success")
        return redirect(url_for('settings'))
    except Exception as e:
        logger.exception("Error saving configuration")
        flash(f"Error saving configuration: {str(e)}", "danger")
        return redirect(url_for('settings'))

@app.route('/api/interfaces')
def get_interfaces():
    """API endpoint to get available network interfaces"""
    try:
        interfaces = network_manager.get_interfaces()
        return jsonify({"success": True, "interfaces": interfaces})
    except Exception as e:
        logger.exception("Error getting interfaces")
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/metrics')
def get_metrics():
    """API endpoint to get network metrics"""
    try:
        metrics = network_monitor.get_network_metrics()
        return jsonify({"success": True, "metrics": metrics})
    except Exception as e:
        logger.exception("Error getting metrics")
        return jsonify({"success": False, "error": str(e)}), 500

@app.route('/api/clients')
def get_clients():
    """API endpoint to get connected clients"""
    try:
        clients = network_monitor.get_connected_clients()
        return jsonify({"success": True, "clients": clients})
    except Exception as e:
        logger.exception("Error getting clients")
        return jsonify({"success": False, "error": str(e)}), 500

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('500.html'), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
