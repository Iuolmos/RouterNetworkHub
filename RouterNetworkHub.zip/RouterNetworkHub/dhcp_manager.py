import os
import subprocess
import logging
import tempfile
from config import ConfigManager

logger = logging.getLogger(__name__)

class DHCPManager:
    """Manages DHCP server for LAN interfaces"""
    
    def __init__(self, config_manager):
        self.config_manager = config_manager
        self.dnsmasq_process = None
        self.dnsmasq_conf_file = None
    
    def start_dhcp_server(self):
        """Start DHCP server on configured LAN interfaces"""
        config = self.config_manager.get_config()
        
        # Skip if DHCP is disabled in config
        if not config.get('dhcp_enabled', True):
            logger.info("DHCP server is disabled in configuration")
            return
        
        lan_interfaces = config.get('lan_interfaces', [])
        if not lan_interfaces:
            logger.warning("No LAN interfaces configured for DHCP")
            return
        
        # Stop any existing DHCP server
        self.stop_dhcp_server()
        
        # Create dnsmasq configuration
        self.dnsmasq_conf_file = self._create_dnsmasq_config(config)
        
        # Start dnsmasq
        try:
            logger.info(f"Starting DHCP server with config file {self.dnsmasq_conf_file}")
            self.dnsmasq_process = subprocess.Popen(
                ["dnsmasq", "-C", self.dnsmasq_conf_file, "--no-daemon"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            logger.info("DHCP server started successfully")
        except Exception as e:
            logger.error(f"Failed to start DHCP server: {str(e)}")
            raise RuntimeError(f"Failed to start DHCP server: {str(e)}")
    
    def stop_dhcp_server(self):
        """Stop the DHCP server"""
        if self.dnsmasq_process:
            logger.info("Stopping DHCP server")
            self.dnsmasq_process.terminate()
            self.dnsmasq_process = None
        
        # Clean up config file
        if self.dnsmasq_conf_file and os.path.exists(self.dnsmasq_conf_file):
            try:
                os.remove(self.dnsmasq_conf_file)
                self.dnsmasq_conf_file = None
            except:
                pass
        
        # Make sure all dnsmasq instances are stopped
        try:
            subprocess.run(["pkill", "dnsmasq"], check=False)
        except:
            pass
        
        logger.info("DHCP server stopped")
    
    def _create_dnsmasq_config(self, config):
        """Create dnsmasq configuration file for DHCP server"""
        lan_interfaces = config.get('lan_interfaces', [])
        dhcp_start = config.get('dhcp_start', '100')
        dhcp_end = config.get('dhcp_end', '200')
        subnet_mask = config.get('subnet_mask', '255.255.255.0')
        
        # Create temporary file for dnsmasq configuration
        fd, conf_file = tempfile.mkstemp(prefix="lanhub_dnsmasq_", suffix=".conf")
        
        with os.fdopen(fd, 'w') as f:
            f.write("# LAN Hub DHCP server configuration\n")
            f.write("# Generated automatically - do not edit\n\n")
            
            # Basic settings
            f.write("domain-needed\n")
            f.write("bogus-priv\n")
            f.write("no-resolv\n")
            f.write("no-hosts\n")
            
            # Use Google DNS
            f.write("server=8.8.8.8\n")
            f.write("server=8.8.4.4\n")
            
            # Configure DHCP for each LAN interface
            for i, interface in enumerate(lan_interfaces):
                subnet_id = i + 1
                f.write(f"\n# Configuration for {interface}\n")
                f.write(f"interface={interface}\n")
                
                # Set DHCP range: from 192.168.<subnet_id>.<dhcp_start> to 192.168.<subnet_id>.<dhcp_end>
                # with subnet mask, and lease time of 12h
                f.write(f"dhcp-range=192.168.{subnet_id}.{dhcp_start},192.168.{subnet_id}.{dhcp_end},{subnet_mask},12h\n")
                
                # Set gateway
                f.write(f"dhcp-option={interface},3,192.168.{subnet_id}.1\n")
                
                # Set DNS server to our own
                f.write(f"dhcp-option={interface},6,192.168.{subnet_id}.1\n")
            
            # General settings
            f.write("\n# General settings\n")
            f.write("log-queries\n")
            f.write("log-dhcp\n")
            f.write("log-facility=-\n")  # Log to stdout/stderr
            
        logger.info(f"Created dnsmasq configuration file: {conf_file}")
        return conf_file
