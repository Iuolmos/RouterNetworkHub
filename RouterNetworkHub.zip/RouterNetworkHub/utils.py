import os
import re
import socket
import struct
import subprocess
import logging

logger = logging.getLogger(__name__)

def is_valid_ip(ip):
    """Check if a string is a valid IPv4 address"""
    pattern = r'^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$'
    match = re.match(pattern, ip)
    
    if not match:
        return False
    
    for octet in match.groups():
        if int(octet) > 255:
            return False
    
    return True

def is_valid_mac(mac):
    """Check if a string is a valid MAC address"""
    pattern = r'^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$'
    return bool(re.match(pattern, mac))

def get_ip_network(ip, subnet_mask):
    """Get network address from IP and subnet mask"""
    # Convert string IP to integer
    ip_int = struct.unpack('!I', socket.inet_aton(ip))[0]
    
    # Convert string subnet mask to integer
    mask_int = struct.unpack('!I', socket.inet_aton(subnet_mask))[0]
    
    # Calculate network address
    network_int = ip_int & mask_int
    
    # Convert back to string
    return socket.inet_ntoa(struct.pack('!I', network_int))

def get_broadcast_address(ip, subnet_mask):
    """Get broadcast address from IP and subnet mask"""
    # Convert string IP to integer
    ip_int = struct.unpack('!I', socket.inet_aton(ip))[0]
    
    # Convert string subnet mask to integer
    mask_int = struct.unpack('!I', socket.inet_aton(subnet_mask))[0]
    
    # Calculate broadcast address (network + inverted mask)
    broadcast_int = ip_int | (~mask_int & 0xFFFFFFFF)
    
    # Convert back to string
    return socket.inet_ntoa(struct.pack('!I', broadcast_int))

def format_bytes(bytes, precision=2):
    """Format bytes to human-readable format"""
    if bytes < 1024:
        return f"{bytes} B"
    
    suffixes = ['B', 'KB', 'MB', 'GB', 'TB', 'PB']
    suffix_index = 0
    
    while bytes >= 1024 and suffix_index < len(suffixes) - 1:
        bytes /= 1024.0
        suffix_index += 1
    
    return f"{bytes:.{precision}f} {suffixes[suffix_index]}"

def check_command_exists(command):
    """Check if a command exists in the system"""
    try:
        subprocess.check_output(["which", command], stderr=subprocess.STDOUT)
        return True
    except subprocess.CalledProcessError:
        return False

def check_required_packages():
    """Check if all required packages are installed"""
    required_commands = ["iptables", "ip", "dnsmasq", "sysctl"]
    missing = []
    
    for cmd in required_commands:
        if not check_command_exists(cmd):
            missing.append(cmd)
    
    return missing

def check_user_permissions():
    """Check if the current user has sufficient permissions (root)"""
    return os.geteuid() == 0

def generate_subnet_mask(cidr):
    """Generate subnet mask from CIDR notation"""
    # Convert CIDR to integer
    try:
        cidr = int(cidr)
        if cidr < 0 or cidr > 32:
            return None
    except ValueError:
        return None
    
    # Create bit mask
    mask_int = (0xFFFFFFFF << (32 - cidr)) & 0xFFFFFFFF
    
    # Convert to string
    return socket.inet_ntoa(struct.pack('!I', mask_int))

def cidr_to_netmask(cidr):
    """Convert CIDR to subnet mask"""
    subnet_bits = "1" * int(cidr) + "0" * (32 - int(cidr))
    subnet_octets = [subnet_bits[i:i+8] for i in range(0, 32, 8)]
    subnet_ints = [int(octet, 2) for octet in subnet_octets]
    return ".".join(str(i) for i in subnet_ints)

def netmask_to_cidr(netmask):
    """Convert subnet mask to CIDR notation"""
    return bin(struct.unpack('!I', socket.inet_aton(netmask))[0]).count('1')
