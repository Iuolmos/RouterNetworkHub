import os
import subprocess
import logging
import re
import time
import threading
import json
from collections import deque
from datetime import datetime
from config import ConfigManager

logger = logging.getLogger(__name__)

class NetworkMonitor:
    """Monitors network traffic and connected clients"""
    
    def __init__(self, config_manager):
        self.config_manager = config_manager
        self.monitoring = False
        self.monitor_thread = None
        
        # Metrics storage - deques for time series data (5 minute history with 30s intervals)
        self.metrics_history = {
            'timestamp': deque(maxlen=10),
            'traffic_in': deque(maxlen=10),
            'traffic_out': deque(maxlen=10),
            'clients': deque(maxlen=10)
        }
        
        # Connected clients
        self.connected_clients = []
        
        # Traffic counters
        self.last_rx_bytes = {}
        self.last_tx_bytes = {}
        self.last_update_time = None
    
    def start_monitoring(self):
        """Start network monitoring in a background thread"""
        if self.monitoring:
            logger.info("Monitoring already running")
            return
        
        logger.info("Starting network monitoring")
        self.monitoring = True
        self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
        self.monitor_thread.start()
    
    def stop_monitoring(self):
        """Stop network monitoring"""
        if not self.monitoring:
            logger.info("Monitoring not running")
            return
        
        logger.info("Stopping network monitoring")
        self.monitoring = False
        if self.monitor_thread:
            self.monitor_thread.join(timeout=3)
            self.monitor_thread = None
    
    def get_network_metrics(self):
        """Get current network metrics"""
        metrics = {
            'timestamp': list(self.metrics_history['timestamp']),
            'traffic_in': list(self.metrics_history['traffic_in']),
            'traffic_out': list(self.metrics_history['traffic_out']),
            'client_count': list(self.metrics_history['clients']),
            'current': {
                'traffic_in': self.metrics_history['traffic_in'][-1] if self.metrics_history['traffic_in'] else 0,
                'traffic_out': self.metrics_history['traffic_out'][-1] if self.metrics_history['traffic_out'] else 0,
                'client_count': len(self.connected_clients)
            }
        }
        return metrics
    
    def get_connected_clients(self):
        """Get list of connected clients"""
        return self.connected_clients
    
    def _monitor_loop(self):
        """Background monitoring loop"""
        config = self.config_manager.get_config()
        lan_interfaces = config.get('lan_interfaces', [])
        
        # Initialize counters
        self._init_counters(lan_interfaces)
        
        update_interval = 30  # seconds
        
        while self.monitoring:
            try:
                # Record metrics
                self._update_traffic_metrics(lan_interfaces)
                self._update_connected_clients(lan_interfaces)
                
                # Sleep for a bit
                time.sleep(update_interval)
            
            except Exception as e:
                logger.error(f"Error in monitor loop: {str(e)}")
                time.sleep(5)  # Sleep a bit before retrying
    
    def _init_counters(self, interfaces):
        """Initialize traffic counters for interfaces"""
        self.last_rx_bytes = {}
        self.last_tx_bytes = {}
        
        for interface in interfaces:
            try:
                rx, tx = self._get_interface_traffic(interface)
                self.last_rx_bytes[interface] = rx
                self.last_tx_bytes[interface] = tx
            except:
                self.last_rx_bytes[interface] = 0
                self.last_tx_bytes[interface] = 0
        
        self.last_update_time = time.time()
    
    def _update_traffic_metrics(self, interfaces):
        """Update traffic metrics for all interfaces"""
        now = time.time()
        time_diff = now - (self.last_update_time or now)
        
        if time_diff <= 0:
            return
        
        # Get current traffic counts
        total_rx_bytes = 0
        total_tx_bytes = 0
        
        for interface in interfaces:
            try:
                rx, tx = self._get_interface_traffic(interface)
                
                # Calculate delta
                rx_diff = rx - self.last_rx_bytes.get(interface, 0)
                tx_diff = tx - self.last_tx_bytes.get(interface, 0)
                
                # Update counters
                self.last_rx_bytes[interface] = rx
                self.last_tx_bytes[interface] = tx
                
                # Add to totals (convert to KB/s)
                total_rx_bytes += rx_diff / time_diff / 1024
                total_tx_bytes += tx_diff / time_diff / 1024
            
            except Exception as e:
                logger.error(f"Error updating traffic for {interface}: {str(e)}")
        
        # Update history
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.metrics_history['timestamp'].append(timestamp)
        self.metrics_history['traffic_in'].append(round(total_rx_bytes, 2))
        self.metrics_history['traffic_out'].append(round(total_tx_bytes, 2))
        self.metrics_history['clients'].append(len(self.connected_clients))
        
        self.last_update_time = now
    
    def _update_connected_clients(self, interfaces):
        """Update connected clients list"""
        connected_clients = []
        
        # Use ARP table to find connected clients
        try:
            arp_output = subprocess.check_output(["arp", "-n"]).decode('utf-8')
            
            for line in arp_output.splitlines():
                if "eth" in line or "wlan" in line:  # Only consider Ethernet/WiFi interfaces
                    parts = line.split()
                    if len(parts) >= 5:
                        ip_address = parts[0]
                        mac_address = parts[2]
                        interface = parts[4]
                        
                        # Only consider our LAN interfaces
                        if interface in interfaces:
                            # Try to get hostname
                            hostname = self._get_hostname_for_ip(ip_address)
                            
                            connected_clients.append({
                                'ip_address': ip_address,
                                'mac_address': mac_address,
                                'interface': interface,
                                'hostname': hostname,
                                'last_seen': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                            })
            
            self.connected_clients = connected_clients
        
        except Exception as e:
            logger.error(f"Error updating connected clients: {str(e)}")
    
    def _get_interface_traffic(self, interface):
        """Get RX/TX byte counts for an interface"""
        try:
            with open(f"/sys/class/net/{interface}/statistics/rx_bytes", 'r') as f:
                rx_bytes = int(f.read().strip())
            
            with open(f"/sys/class/net/{interface}/statistics/tx_bytes", 'r') as f:
                tx_bytes = int(f.read().strip())
            
            return rx_bytes, tx_bytes
        
        except Exception as e:
            logger.error(f"Error reading traffic for {interface}: {str(e)}")
            return 0, 0
    
    def _get_hostname_for_ip(self, ip_address):
        """Try to resolve hostname for an IP address"""
        try:
            hostname = subprocess.check_output(["getent", "hosts", ip_address]).decode('utf-8').split()[1]
            return hostname
        except:
            return None
